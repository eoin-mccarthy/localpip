## @file pyVim/__init__.py
## @brief A client-side Python API that wraps pyVmomi.
##
##

##
## @mainpage
##
## A client-side Python API that wraps pyVmomi.
##
##

